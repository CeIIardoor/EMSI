package emsi;

public class Etudiant extends Personne {

    String cne;
    double note;

    public Etudiant(){

    }
    public Etudiant(String n, int a, String cne, double note) {
        super(n, a);
        this.cne = cne;
        this.note = note;
    }

    @Override
    public String toString() {
        return super.toString() +
                "cne='" + cne + '\'' +
                ", note=" + note +
                '}';
    }
}
