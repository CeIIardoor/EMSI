package emsi;

import java.util.Collection;
import java.util.Comparator;
import java.util.List;
import java.util.Objects;

public  class Personne implements Comparable<Personne> {
    public int age;
    public String nom;

    public  String cin;

    public Personne(){}
    public Personne(String n, int a){
        this.age = a;
        this.nom = n;
    }

    public Personne(String n, int a, String cin){
        this.age = a;
        this.nom = n;
        this.cin = cin;
    }

    @Override
    public String toString() {
        return "Personne{" +
                "age=" + age +
                ", nom='" + nom + '\'' +
                ", cin = " + cin +
                '}';
    }


    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Personne personne = (Personne) o;
        return age == personne.age && Objects.equals(nom, personne.nom);
    }

    @Override
    public int hashCode() {
        return Objects.hash(age, nom);
    }

    @Override
    public int compareTo(Personne o) {
        return this.nom.compareTo(o.nom);}
}
