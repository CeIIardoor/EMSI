package emsi;


import java.util.*;

public class App

{

    static void afficher(List<? super Personne> personnes){

        personnes.forEach(personne -> System.out.println(personne));
    }


    public static void main( String[] args )
    {
        List<String> names =
                new ArrayList<>
                        (Arrays.asList("Hiba", "Aya", "Mehdi", "Nizar", "Mehdi"));

        List<Personne> Personnes = new ArrayList<>();

        for (int i = 0; i < names.size(); i++) {

           Personne pi =  new Personne(names.get(i) , 18+i );
            Personnes.add(pi);
        }



       Etudiant e1 =  new Etudiant("Amine",20,"234567654",15.0);
        Etudiant e2 =  new Etudiant("Nizar",22,"234215888",13.0);
        Etudiant e3 =  new Etudiant("Zakaria",21,"98765432",17.0);

        List<Etudiant> Lesetudiants = new ArrayList<Etudiant>(Arrays.asList(e1,e2,e3));


           Personne p = new Etudiant();


        Professeur p1 =  new Professeur("Amine",20,"Math",15000.0);
        Professeur p2 =  new Professeur("Nizar",22,"Infos",13000.0);
        Professeur p3 =  new Professeur("Zakaria",21,"Pgysique",17000.0);


        List<Professeur> professeurs = new ArrayList<Professeur>(Arrays.asList(p1,p2,p3));

        Personnes.add(p1);

List<Comparable> l = new ArrayList<>();
        afficher(l);
    }


}

