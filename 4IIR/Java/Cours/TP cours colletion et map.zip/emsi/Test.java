package emsi;

import java.util.*;

public class Test {


    public static void afficher(Personne personne) {

        System.out.println(personne.nom + " agé de "
                        + personne.age + "ans ayant le n°Cin : "+ personne.cin );
    }


    public static void afficherNotes(Personne personne,  List<Double> notes) {

        System.out.println("\n" +personne.nom + " [cin : " + personne.cin +  "]\n\t\t\t => notes : " + notes);
    }

    public static void main(String[] args) {

        List<Personne> personnes = new ArrayList<>(
                Arrays.asList(new Personne("Zineb", 22, "AA3453"), new Personne("Sara", 21, "AB21467"))
        );
        personnes.add(0, new Personne("Sulaiman", 23, "C1236"));
        personnes.add(3, new Personne("Sulaiman", 23, "C5544"));

        System.out.println("List des Personnes : ");
        personnes.forEach(Test::afficher);
        System.out.println();

        Set<Personne> personSet = new HashSet<>(
                Arrays.asList(new Personne("Zineb", 22, "AA3453"), new Personne("Sara", 21, "AB21467"))
        );
        personSet.add(new Personne("Sulaiman", 23, "C1236"));

        // cet objet ne va pas être ajouté, car la fonction hashCode et equals
        // se basent seulement sur le nom et l'age
        personSet.add(new Personne("Sulaiman", 23, "C5544"));

        System.out.println("\nSet des Personnes : ");
        personSet.forEach(Test::afficher);
        System.out.println();

        Map<Personne, List<Double>> notes = new HashMap<>();

        for(Personne p : personnes)
                    notes.put(p, new ArrayList<Double>());

        Iterator<Personne> it = notes.keySet().iterator();

        while (it.hasNext()){



            Personne personne = it.next();
            for (int i = 0; i < 6; i++) {
                Random r = new Random();
                double randomValue = 5.0 + (20.0 - 5.0) * r.nextDouble();
                randomValue = (double)Math.round(randomValue*10)/10;
                notes.get(personne).add(randomValue);
            }


        }
        notes.forEach(Test::afficherNotes);
    }}
