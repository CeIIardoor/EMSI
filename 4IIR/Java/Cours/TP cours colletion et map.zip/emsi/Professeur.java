package emsi;

public class Professeur extends Personne {

    Double salaire;
    String specialite;

    public Professeur(){

    }
    public Professeur(String n, int a, String spe, double salaire) {
        super(n, a);
        this.salaire = salaire;
        this.specialite = spe;
    }

    @Override
    public String toString() {
        return super.toString() +
                "specialite='" + specialite + '\'' +
                ", Salaire=" + salaire +
                '}';
    }
}
