package collections;


import java.util.*;
import java.util.function.Predicate;
import java.util.stream.Collectors;

enum Sexe{

    Homme(0,"H"), Femme(1,"F");


    int indice;
    String abreviation;
   Sexe(){

   }
    Sexe(int indice, String abv){

       this.indice = indice;
       this.abreviation = abv;

    }



}
class Personne implements Comparable<Personne> {
    String nom, prenom;
    Integer age;
    Sexe sexe;

    Personne(){}
    Personne(String n, String p, int a, Sexe s){
        this.nom = n;
        prenom = p; age = a; sexe = s;
    }

    @Override
    public String toString() {
        return "Personne{" +
                "nom='" + nom + '\'' +
                ", prenom='" + prenom + '\'' +
                ", age=" + age +
                ", sexe=" + sexe +
                '}';
    }

    @Override
    public int compareTo(Personne p) {
        if(this.nom.compareTo(p.nom) ==0)
            if(this.prenom.compareTo(p.prenom)==0)
                if(age.compareTo(p.age)==0)
                    return sexe.compareTo(p.sexe);
                else return age.compareTo(p.age);
            else return prenom.compareTo(p.prenom);
        else return nom.compareTo(p.nom);
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Personne personne = (Personne) o;
        return Objects.equals(nom, personne.nom) && Objects.equals(prenom, personne.prenom) && Objects.equals(age, personne.age) && sexe == personne.sexe;
    }

    @Override
    public int hashCode() {
        return Objects.hash(nom, prenom, age, sexe);
    }
}



public class Test {


    static void trierParAgeAsc(List<Personne> personnes){

        Collections.sort(personnes, (p1,p2) -> p2.age.compareTo(p1.age));
    }
    static void trierParAgeDesc(List<Personne> personnes){

        trierParAgeAsc(personnes);
        Collections.reverse(personnes);
    }


    public static void main(String[] args) {




        Personne p1 = new Personne("El Alaoui","Amine",21, Sexe.Homme);
        Personne p2 = new Personne("Alami","Sara",23, Sexe.Femme);
        Personne p3 = new Personne("Nadir","Bilal",25, Sexe.Homme);
        Personne p4 = new Personne("Salamat","med amine",28, Sexe.Homme);
        Personne p5 = new Personne("Alami","Houda",20, Sexe.Femme);
        Personne p6 = new Personne("Jaoui","Adam",19, Sexe.Homme);

        Set<Personne> personnes = new HashSet<>(Arrays.asList(p1,p2,p3,p4,p5,p6));

        personnes.forEach(p-> System.out.println(p));
    }
}
